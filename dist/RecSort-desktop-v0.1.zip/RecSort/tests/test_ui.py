import os
os.environ.setdefault('QT_QPA_PLATFORM', 'offscreen')
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QApplication, QDialog, QCheckBox, QDialogButtonBox
from recsort.app import Window
from recsort.core import scan

APP = QApplication.instance() or QApplication([])

class UITests(unittest.TestCase):
    def setUp(self):
        self.window = Window()
    def tearDown(self):
        self.window.close()
    def test_demo_filter_and_trash_disabled(self):
        self.window.load_demo()
        self.assertEqual(self.window.table.rowCount(), 6)
        self.window.only.setChecked(True)
        self.assertEqual(self.window.table.rowCount(), 4)
        self.window.table.item(0, 0).setCheckState(Qt.CheckState.Checked)
        self.assertFalse(self.window.trash_button.isEnabled())
        self.window.search.setText('録画テスト')
        self.assertEqual(self.window.table.rowCount(), 1)
    def prepare(self, root):
        p = Path(root) / 'test.mp4'
        p.write_bytes(b'test')
        self.window.root = Path(root)
        self.window.records = scan(root)[0]
        self.window.render()
        self.window.table.item(0, 0).setCheckState(Qt.CheckState.Checked)
        return p
    def test_cancel_never_calls_trash(self):
        with tempfile.TemporaryDirectory() as root:
            p = self.prepare(root)
            def cancel():
                dialog = APP.activeModalWidget()
                self.assertIsInstance(dialog, QDialog)
                buttons = dialog.findChild(QDialogButtonBox)
                accept = [b for b in buttons.buttons() if buttons.buttonRole(b) == QDialogButtonBox.ButtonRole.AcceptRole][0]
                self.assertFalse(accept.isEnabled())
                dialog.reject()
            with patch('recsort.app.send2trash') as trash:
                QTimer.singleShot(0, cancel)
                self.window.confirm_trash()
                trash.assert_not_called()
                self.assertTrue(p.exists())
    def test_explicit_confirmation_calls_service(self):
        with tempfile.TemporaryDirectory() as root:
            self.prepare(root)
            def accept():
                dialog = APP.activeModalWidget()
                dialog.findChild(QCheckBox).setChecked(True)
                buttons = dialog.findChild(QDialogButtonBox)
                button = [b for b in buttons.buttons() if buttons.buttonRole(b) == QDialogButtonBox.ButtonRole.AcceptRole][0]
                button.click()
            with patch('recsort.app.send2trash') as trash:
                QTimer.singleShot(0, accept)
                self.window.confirm_trash()
                trash.assert_called_once()
                self.assertEqual(self.window.table.rowCount(), 0)
    def test_background_scan(self):
        with tempfile.TemporaryDirectory() as root:
            (Path(root) / 'test.mp4').write_bytes(b'test')
            self.window.root = Path(root)
            self.window.start_scan()
            self.assertTrue(self.window.worker.wait(5000))
            APP.processEvents()
            self.assertEqual(len(self.window.records), 1)
            self.assertTrue(self.window.choose.isEnabled())
