import os
import tempfile
import unittest
from pathlib import Path
from recsort.core import scan, trash_record

class CoreTests(unittest.TestCase):
    def test_scan_filters_and_recurses(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            (root / 'sub').mkdir()
            (root / 'sub' / 'video.MP4').write_bytes(b'video')
            (root / 'ignore.txt').write_text('ignore')
            try:
                (root / 'linked.mp4').symlink_to(root / 'sub' / 'video.MP4')
            except OSError:
                pass
            rows, warnings = scan(root)
            self.assertEqual(len(rows), 1)
            self.assertEqual(rows[0].size, 5)
            self.assertFalse(warnings)

    def test_reasons_and_read_only_scan(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'empty.ts'
            p.touch()
            os.utime(p, (1, 1))
            rows, _ = scan(d)
            self.assertEqual(len(rows[0].reasons(now=86400 * 100)), 2)
            self.assertTrue(p.exists())

    def test_stale_and_outside_paths_never_reach_trash(self):
        with tempfile.TemporaryDirectory() as d, tempfile.TemporaryDirectory() as other:
            p = Path(d) / 'a.mp4'
            p.write_bytes(b'one')
            row = scan(d)[0][0]
            calls = []
            with self.assertRaises(ValueError):
                trash_record(row, other, calls.append)
            p.write_bytes(b'changed')
            with self.assertRaises(ValueError):
                trash_record(row, d, calls.append)
            self.assertEqual(calls, [])
            self.assertTrue(p.exists())

    def test_valid_trash_uses_injected_service(self):
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'a.mp4'
            p.write_bytes(b'one')
            row = scan(d)[0][0]
            calls = []
            trash_record(row, d, calls.append)
            self.assertEqual(calls, [str(p.resolve())])
            self.assertTrue(p.exists())

if __name__ == '__main__':
    unittest.main()
