from dataclasses import dataclass
from pathlib import Path
import os
import stat
import time

EXTENSIONS = {'.mp4', '.mkv', '.mov', '.avi', '.ts', '.mts', '.m2ts', '.webm', '.m4v', '.wmv'}

@dataclass(frozen=True)
class Recording:
    path: Path
    size: int
    mtime_ns: int
    device: int
    inode: int

    def reasons(self, days=90, gib=2, now=None):
        age = max(0, ((time.time() if now is None else now) - self.mtime_ns / 1e9) / 86400)
        result = []
        if age >= days:
            result.append(f'最終更新から{int(age)}日経過（基準{days}日）')
        if self.size >= gib * 1024**3:
            result.append(f'{gib:g} GB以上の大容量')
        if self.size == 0:
            result.append('0バイト：録画失敗の可能性')
        return result

def scan(folder, cancelled=lambda: False):
    root = Path(folder).resolve(strict=True)
    if not root.is_dir():
        raise ValueError('フォルダを選択してください。')
    records, warnings = [], []
    def onerror(error):
        warnings.append(str(error))
    for directory, dirs, files in os.walk(root, followlinks=False, onerror=onerror):
        dirs[:] = [d for d in dirs if not (Path(directory) / d).is_symlink()]
        for name in files:
            if cancelled():
                return records, warnings
            path = Path(directory) / name
            if path.suffix.lower() not in EXTENSIONS:
                continue
            try:
                s = path.lstat()
                if stat.S_ISREG(s.st_mode) and not path.is_symlink():
                    records.append(Recording(path, s.st_size, s.st_mtime_ns, s.st_dev, s.st_ino))
            except OSError as error:
                warnings.append(f'{path}: {error}')
    return sorted(records, key=lambda r: r.mtime_ns, reverse=True), warnings

def trash_record(record, root, trash):
    """Only called after explicit UI confirmation; reject stale scan entries."""
    path = record.path
    if path.is_symlink() or not path.resolve(strict=True).is_relative_to(Path(root).resolve(strict=True)):
        raise ValueError('対象がフォルダ外、またはリンクに変更されています。再スキャンしてください。')
    s = path.lstat()
    if not stat.S_ISREG(s.st_mode) or (s.st_size, s.st_mtime_ns, s.st_dev, s.st_ino) != (record.size, record.mtime_ns, record.device, record.inode):
        raise ValueError('スキャン後にファイルが変更されました。再スキャンしてください。')
    trash(str(path))

def size_text(size):
    for unit in ('B', 'KB', 'MB', 'GB', 'TB'):
        if size < 1024 or unit == 'TB':
            return f'{size:,.1f} {unit}'
        size /= 1024
