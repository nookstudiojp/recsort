import sys
import time
from pathlib import Path
from datetime import datetime
from PySide6.QtCore import Qt, QThread, Signal, QTimer
from PySide6.QtGui import QColor
from PySide6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QPushButton, QFileDialog, QLineEdit, QCheckBox, QSpinBox, QDoubleSpinBox,
    QTableWidget, QTableWidgetItem, QHeaderView, QMessageBox, QDialog, QTextEdit, QDialogButtonBox)
from send2trash import send2trash
from .core import Recording, scan, trash_record, size_text

class ScanWorker(QThread):
    completed = Signal(object, object)
    failed = Signal(str)
    def __init__(self, folder):
        super().__init__()
        self.folder = folder
    def run(self):
        try:
            rows, warnings = scan(self.folder, self.isInterruptionRequested)
            self.completed.emit(rows, warnings)
        except Exception as error:
            self.failed.emit(str(error))

class NumericItem(QTableWidgetItem):
    def __lt__(self, other):
        return self.data(Qt.ItemDataRole.UserRole) < other.data(Qt.ItemDataRole.UserRole)

class Window(QMainWindow):
    def __init__(self):
        super().__init__()
        self.records, self.root, self.worker = [], None, None
        self.demo = False
        self.setWindowTitle('RecSort — 録画を、すっきり。')
        self.resize(1180, 760)
        container = QWidget()
        self.setCentralWidget(container)
        layout = QVBoxLayout(container)
        layout.setContentsMargins(28, 24, 28, 24)
        layout.setSpacing(16)
        title = QLabel('RecSort   /   録画を、すっきり。')
        title.setObjectName('title')
        layout.addWidget(title)
        layout.addWidget(QLabel('RECORDING LIBRARY   •   ローカルの動画を整理するワークスペース'))
        folder_bar = QHBoxLayout()
        self.path_label = QLineEdit()
        self.path_label.setReadOnly(True)
        self.path_label.setPlaceholderText('録画フォルダを選択してください（サブフォルダもスキャン）')
        self.choose = QPushButton('フォルダを選択')
        self.choose.clicked.connect(self.choose_folder)
        self.rescan = QPushButton('再スキャン')
        self.rescan.clicked.connect(self.start_scan)
        self.rescan.setEnabled(False)
        self.demo_button = QPushButton('デモを見る')
        self.demo_button.clicked.connect(self.load_demo)
        for widget in (self.path_label, self.choose, self.rescan, self.demo_button):
            folder_bar.addWidget(widget)
        layout.addLayout(folder_bar)
        self.summary = QLabel('0 件   /   合計 0 B   /   整理候補 0 件')
        self.summary.setObjectName('summary')
        layout.addWidget(self.summary)
        filters = QHBoxLayout()
        self.search = QLineEdit()
        self.search.setPlaceholderText('ファイル名・パスで検索')
        self.search.textChanged.connect(self.render)
        self.only = QCheckBox('候補のみ')
        self.only.toggled.connect(self.render)
        self.days = QSpinBox()
        self.days.setRange(1, 3650)
        self.days.setValue(90)
        self.days.setSuffix(' 日')
        self.days.valueChanged.connect(self.render)
        self.gib = QDoubleSpinBox()
        self.gib.setRange(0.1, 10000)
        self.gib.setValue(2)
        self.gib.setSuffix(' GB')
        self.gib.valueChanged.connect(self.render)
        for w in (self.search, self.only, QLabel('古さの基準'), self.days, QLabel('容量の基準'), self.gib):
            filters.addWidget(w)
        layout.addLayout(filters)
        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(['選択', 'ファイル名', '容量', '最終更新日時', '整理候補の理由'])
        self.table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.Stretch)
        self.table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.Stretch)
        self.table.setColumnWidth(0, 55)
        self.table.setColumnWidth(2, 100)
        self.table.setColumnWidth(3, 160)
        self.table.verticalHeader().hide()
        self.table.setAlternatingRowColors(True)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        self.table.itemChanged.connect(self.update_selection)
        layout.addWidget(self.table, 1)
        layout.addWidget(QLabel('候補は容量・更新日時による目安です。動画の内容や視聴済みかどうかは判定しません。'))
        actions = QHBoxLayout()
        clear = QPushButton('選択を解除')
        clear.clicked.connect(self.clear_selection)
        self.selected = QLabel('選択 0 件')
        self.trash_button = QPushButton('選択した動画をゴミ箱へ…')
        self.trash_button.setObjectName('danger')
        self.trash_button.setEnabled(False)
        self.trash_button.clicked.connect(self.confirm_trash)
        actions.addWidget(clear)
        actions.addWidget(self.selected)
        actions.addStretch()
        actions.addWidget(self.trash_button)
        layout.addLayout(actions)
        self.status = QLabel('フォルダを選ぶか「デモを見る」で始めましょう。自動削除は行いません。')
        self.status.setWordWrap(True)
        layout.addWidget(self.status)

    def choose_folder(self):
        folder = QFileDialog.getExistingDirectory(self, '録画フォルダを選択')
        if folder:
            self.root = Path(folder).resolve()
            self.demo = False
            self.path_label.setText(str(self.root))
            self.start_scan()

    def set_busy(self, busy):
        for w in (self.choose, self.demo_button, self.rescan):
            w.setEnabled(not busy)
        self.trash_button.setEnabled(not busy and bool(self.checked()) and not self.demo)

    def start_scan(self):
        if self.root is None or (self.worker and self.worker.isRunning()):
            return
        self.records = []
        self.render()
        self.set_busy(True)
        self.status.setText('スキャン中… 大きいフォルダでは時間がかかります。')
        self.worker = ScanWorker(self.root)
        self.worker.completed.connect(self.scan_done)
        self.worker.failed.connect(self.scan_failed)
        self.worker.finished.connect(lambda: self.set_busy(False))
        self.worker.start()

    def scan_done(self, rows, warnings):
        self.records = rows
        self.render()
        self.status.setText(f'スキャン完了：{len(rows)} 件。' + (f' 読み取れない項目 {len(warnings)} 件（詳細はここにマウスを重ねて確認）。' if warnings else ' 各行のチェックで選択できます。'))
        self.status.setToolTip('\n'.join(warnings))

    def scan_failed(self, message):
        self.status.setText('スキャンできませんでした：' + message)

    def load_demo(self):
        self.demo = True
        self.root = None
        self.path_label.setText('DEMO / 架空のライブラリ（実ファイルはありません）')
        now = time.time()
        samples = [('ゲーム実況_2026-06-15.mp4', 4.8, 141), ('講義_プログラミング入門.mkv', 0.7, 12),
                   ('録画テスト_失敗.ts', 0, 2), ('旅行の思い出.mov', 2.4, 38), ('配信アーカイブ.mp4', 1.3, 110), ('学校発表_リハーサル.mp4', 0.15, 1)]
        self.records = [Recording(Path(name), int(gb * 1024**3), int((now - days * 86400) * 1e9), 0, i) for i, (name, gb, days) in enumerate(samples)]
        self.render()
        self.rescan.setEnabled(False)
        self.status.setText('デモモード：表示・検索・候補の条件変更を試せます。ゴミ箱への移動は無効です。')

    def render(self, *_):
        self.table.blockSignals(True)
        self.table.setSortingEnabled(False)
        self.table.setRowCount(0)
        candidates = 0
        for rec in self.records:
            reasons = rec.reasons(self.days.value(), self.gib.value())
            candidates += bool(reasons)
            if self.search.text().casefold() not in str(rec.path).casefold() or (self.only.isChecked() and not reasons):
                continue
            row = self.table.rowCount()
            self.table.insertRow(row)
            check = QTableWidgetItem()
            check.setFlags(Qt.ItemFlag.ItemIsEnabled | Qt.ItemFlag.ItemIsUserCheckable)
            check.setCheckState(Qt.CheckState.Unchecked)
            check.setData(Qt.ItemDataRole.UserRole, rec)
            self.table.setItem(row, 0, check)
            values = [rec.path.name, size_text(rec.size), datetime.fromtimestamp(rec.mtime_ns / 1e9).strftime('%Y/%m/%d %H:%M'), ' / '.join(reasons) or '—']
            for col, value in enumerate(values, 1):
                item = NumericItem(value) if col in (2, 3) else QTableWidgetItem(value)
                item.setToolTip(str(rec.path) if col == 1 else value)
                if col in (2, 3):
                    item.setData(Qt.ItemDataRole.UserRole, rec.size if col == 2 else rec.mtime_ns)
                if col == 4 and reasons:
                    item.setForeground(QColor('#f6c66c'))
                self.table.setItem(row, col, item)
        self.table.setSortingEnabled(True)
        self.table.blockSignals(False)
        self.summary.setText(f'{len(self.records)} 件の動画    /    合計 {size_text(sum(r.size for r in self.records))}    /    整理候補 {candidates} 件    /    表示 {self.table.rowCount()} 件')
        self.update_selection()

    def checked(self):
        return [self.table.item(row, 0).data(Qt.ItemDataRole.UserRole) for row in range(self.table.rowCount()) if self.table.item(row, 0).checkState() == Qt.CheckState.Checked]

    def update_selection(self, *_):
        rows = self.checked()
        self.selected.setText(f'選択 {len(rows)} 件 / {size_text(sum(r.size for r in rows))}')
        self.trash_button.setEnabled(bool(rows) and not self.demo and not (self.worker and self.worker.isRunning()))

    def clear_selection(self):
        for row in range(self.table.rowCount()):
            self.table.item(row, 0).setCheckState(Qt.CheckState.Unchecked)

    def confirm_trash(self):
        records = self.checked()
        if not records or self.demo:
            return
        dialog = QDialog(self)
        dialog.setWindowTitle('ゴミ箱へ移動する前の確認')
        dialog.resize(680, 430)
        box = QVBoxLayout(dialog)
        box.addWidget(QLabel(f'{len(records)} 件 / {size_text(sum(r.size for r in records))} をゴミ箱へ移動します。\n対象を確認してください。完全削除は行いません。'))
        detail = QTextEdit()
        detail.setReadOnly(True)
        detail.setPlainText('\n\n'.join(f'{r.path}\n{size_text(r.size)}' for r in records))
        box.addWidget(detail)
        consent = QCheckBox('上記のファイルを確認しました')
        box.addWidget(consent)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        go = buttons.addButton('確認してゴミ箱へ移動', QDialogButtonBox.ButtonRole.AcceptRole)
        go.setEnabled(False)
        consent.toggled.connect(go.setEnabled)
        buttons.rejected.connect(dialog.reject)
        buttons.accepted.connect(dialog.accept)
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setDefault(True)
        go.setAutoDefault(False)
        box.addWidget(buttons)
        if dialog.exec() != QDialog.DialogCode.Accepted:
            return
        errors, moved = [], []
        for rec in records:
            try:
                trash_record(rec, self.root, send2trash)
                moved.append(rec)
            except Exception as error:
                errors.append(f'{rec.path.name}: {error}')
        self.records = [r for r in self.records if r not in moved]
        self.render()
        self.status.setText(f'{len(moved)} 件をゴミ箱へ移動しました。復元はOSのゴミ箱から行ってください。空き容量はゴミ箱を空にするまで増えません。')
        if errors:
            QMessageBox.warning(self, '移動できなかったファイル', '\n'.join(errors))

    def closeEvent(self, event):
        if self.worker and self.worker.isRunning():
            self.worker.requestInterruption()
            self.status.setText('スキャンを停止しています。完了後に閉じてください。')
            event.ignore()
        else:
            event.accept()

STYLE = '''
QWidget { background:#101722; color:#dce4ef; font-size:13px; }
QLabel#title { font-size:28px; font-weight:700; color:#f0f6ff; }
QLabel#summary { background:#1b2c40; padding:20px; border-radius:10px; font-size:17px; color:#70dfc3; }
QPushButton { background:#23354a; border:1px solid #354b63; border-radius:7px; padding:10px 15px; }
QPushButton:hover { background:#304a62; }
QPushButton:disabled { color:#627082; background:#1a2431; }
QPushButton#danger { background:#713841; }
QPushButton#danger:disabled { background:#26232d; color:#716574; }
QLineEdit, QSpinBox, QDoubleSpinBox { background:#172231; border:1px solid #34465c; border-radius:6px; padding:9px; }
QTableWidget { background:#141e2b; alternate-background-color:#192535; border:1px solid #2b3d52; gridline-color:#26384b; }
QHeaderView::section { background:#223247; padding:12px; border:0; color:#a9bfd7; }
QTableWidget::item { padding:8px; }
QTableWidget::item:selected { background:#304c62; }
QCheckBox { spacing:8px; }
QCheckBox::indicator, QTableWidget::indicator { width:16px; height:16px; border:1px solid #70879e; border-radius:3px; background:#172231; }
QCheckBox::indicator:checked, QTableWidget::indicator:checked { background:#56cdb0; border:2px solid #b9ffed; }
QTextEdit { background:#182333; }
'''

def main():
    app = QApplication(sys.argv)
    app.setStyle('Fusion')
    app.setStyleSheet(STYLE)
    window = Window()
    window.show()
    if '--demo' in sys.argv:
        window.load_demo()
    if '--screenshot' in sys.argv:
        target = sys.argv[sys.argv.index('--screenshot') + 1]
        def capture():
            window.grab().save(target)
            app.quit()
        QTimer.singleShot(700, capture)
    sys.exit(app.exec())
